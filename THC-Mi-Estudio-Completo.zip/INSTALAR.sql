CREATE TABLE `cms_assets` (
	`id` text PRIMARY KEY NOT NULL,
	`mime` text NOT NULL,
	`size` integer NOT NULL,
	`created` text NOT NULL
);

CREATE TABLE `cms_editors` (
	`email` text PRIMARY KEY NOT NULL,
	`user_id` text
);

CREATE TABLE `cms_state` (
	`id` text PRIMARY KEY NOT NULL,
	`data` text NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL
);

CREATE TABLE `cms_uploads` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`upload_id` text NOT NULL,
	`mime` text NOT NULL,
	`size` integer NOT NULL,
	`created` integer NOT NULL,
	`parts` text DEFAULT '{}' NOT NULL,
	`status` text DEFAULT 'open' NOT NULL
);

CREATE TABLE `auth_config` (
	`id` integer PRIMARY KEY NOT NULL,
	`salt` text NOT NULL,
	`hash` text NOT NULL,
	`version` integer NOT NULL
);

CREATE TABLE `auth_limits` (
	`id` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires` integer NOT NULL
);

CREATE TABLE `auth_resets` (
	`token` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`version` integer NOT NULL,
	`expires` integer NOT NULL,
	`used` integer DEFAULT 0 NOT NULL
);

CREATE TABLE `auth_sessions` (
	`token` text PRIMARY KEY NOT NULL,
	`email` text NOT NULL,
	`version` integer NOT NULL,
	`expires` integer NOT NULL
);

INSERT INTO auth_config (id,salt,hash,version) VALUES (1,'c83c1924cda6ea5dfc5563e0c9c171afc664b173aec56037015a0edbd78f1f14','aec4076f5e64bacf3896cfa8af1ea3890165932fddbe2d88fd844658cde8e723',1);
