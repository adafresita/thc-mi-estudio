Ver docs/INSTALAR-THC.md. Exportar para Cloudflare Pages: node scripts/export-standalone.mjs ../publicar
