import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const state = sqliteTable('cms_state', {id:text('id').primaryKey(), data:text('data').notNull(), revision:integer('revision').notNull().default(1)});
export const assets = sqliteTable('cms_assets', {id:text('id').primaryKey(), mime:text('mime').notNull(), size:integer('size').notNull(), created:text('created').notNull()});
export const editors = sqliteTable('cms_editors', {email:text('email').primaryKey(), userId:text('user_id')});

export const uploads = sqliteTable('cms_uploads', {id:text('id').primaryKey(), owner:text('owner').notNull(), uploadId:text('upload_id').notNull(), mime:text('mime').notNull(), size:integer('size').notNull(), created:integer('created').notNull(), parts:text('parts').notNull().default('{}'), status:text('status').notNull().default('open')});
export const authConfig = sqliteTable('auth_config',{id:integer('id').primaryKey(),salt:text('salt').notNull(),hash:text('hash').notNull(),version:integer('version').notNull()});
export const authSessions = sqliteTable('auth_sessions',{token:text('token').primaryKey(),email:text('email').notNull(),version:integer('version').notNull(),expires:integer('expires').notNull()});
export const authResets = sqliteTable('auth_resets',{token:text('token').primaryKey(),email:text('email').notNull(),version:integer('version').notNull(),expires:integer('expires').notNull(),used:integer('used').notNull().default(0)});
export const authLimits = sqliteTable('auth_limits',{id:text('id').primaryKey(),count:integer('count').notNull(),expires:integer('expires').notNull()});
