import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import worker from '../worker/index.mjs';
const sql=new DatabaseSync(':memory:');for(const name of readdirSync(new URL('../drizzle/',import.meta.url)).filter(n=>n.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+name,import.meta.url),'utf8'));
const files=new Map();
const env={CMS_OWNER_EMAIL:'risaiaguayo@gmail.com',DB:{prepare(q){const stmt=sql.prepare(q);let args=[];return {bind(...a){args=a;return this},async first(){return stmt.get(...args)||null},async all(){return {results:stmt.all(...args)}},async run(){const result=stmt.run(...args);return {meta:{changes:Number(result.changes)}}}}}},BUCKET:{async put(id,bytes){files.set(id,bytes)},async get(id,options){let body=files.get(id);if(!body)return null;if(options?.range)body=body.slice(options.range.offset,options.range.offset+options.range.length);return {body}},async delete(id){files.delete(id)}}};
function call(path,{method='GET',body,user='owner',headers={}}={}){const h={...headers};if(user){h['oai-authenticated-user-id']=user+'-site-id';h['oai-authenticated-user-email']=({owner:'risaiaguayo@gmail.com',collaborator:'thcm4e@gmail.com'})[user]||user+'@example.com'}if(method!=='GET'){h.Origin='https://test.local';if(!(body instanceof Uint8Array)){h['Content-Type']='application/json';body=JSON.stringify(body)}}return worker.fetch(new Request('https://test.local'+path,{method,headers:h,body}),env)}
test('CMS authorizes, saves drafts, publishes only selected media and rejects conflicts',async()=>{
 assert.equal((await call('/api/admin/state',{user:null})).status,403);
 assert.equal((await call('/api/admin/state',{user:'stranger'})).status,403);
 const initial=await (await call('/api/admin/state')).json();assert.equal(initial.revision,0);
 const image=new Uint8Array([255,216,255,1,2,3,4]);const uploaded=await (await call('/api/admin/upload',{method:'POST',headers:{'Content-Type':'image/jpeg'},body:image})).json();assert.ok(uploaded.id);
 assert.equal((await call('/media/'+uploaded.id,{user:null})).status,404);
 const state=initial.data;state.name='TEST ARTIST';state.cover=uploaded.id;
 const audio=await (await call('/api/admin/upload',{method:'POST',headers:{'Content-Type':'audio/mpeg'},body:new Uint8Array([73,68,51,0,0,0,0,0,0,0])})).json();
 state.beats=[{id:crypto.randomUUID(),title:'Private beat',genre:'Trap',bpm:'120',price:'Consultar',audio:audio.id,cover:'',published:false}];
 assert.equal((await call('/api/admin/state',{method:'PUT',body:{data:state,revision:0}})).status,200);
 assert.equal((await (await call('/api/public',{user:null})).json()).name,'THC');
 assert.equal((await call('/api/admin/state',{method:'PUT',body:{data:state,revision:0}})).status,409);
 assert.equal((await call('/api/admin/publish',{method:'POST',body:{revision:0}})).status,409);
 assert.equal((await call('/api/admin/publish',{method:'POST',body:{revision:1}})).status,200);
 let published=await (await call('/api/public',{user:null})).json();assert.equal(published.name,'TEST ARTIST');assert.equal(published.beats.length,0);
 assert.equal((await call('/media/'+uploaded.id,{user:null})).status,200);assert.equal((await call('/media/'+audio.id,{user:null})).status,404);
 state.beats[0].published=true;await call('/api/admin/state',{method:'PUT',body:{data:state,revision:1}});await call('/api/admin/publish',{method:'POST',body:{revision:2}});
 const range=await call('/media/'+audio.id,{user:null,headers:{Range:'bytes=0-2'}});assert.equal(range.status,206);assert.equal(await range.text(),'ID3');
 state.beats=[];await call('/api/admin/state',{method:'PUT',body:{data:state,revision:2}});await call('/api/admin/publish',{method:'POST',body:{revision:3}});assert.equal((await call('/media/'+audio.id,{user:null})).status,404);
 assert.equal((await call('/api/admin/upload',{method:'POST',headers:{'Content-Type':'image/jpeg'},body:new Uint8Array([1,2,3])})).status,415);
 const request=new Request('https://test.local/api/admin/publish',{method:'POST',headers:{Origin:'https://evil.example','oai-authenticated-user-id':'owner-site-id','oai-authenticated-user-email':'owner@example.com'},body:'{}'});assert.equal((await worker.fetch(request,env)).status,403);
 assert.equal((await call('/api/admin/state',{user:'collaborator'})).status,200);
 assert.equal((await call('/api/admin/editors',{method:'POST',body:{email:'stranger@example.com'}})).status,403);
 assert.equal((await call('/api/admin/state',{user:'stranger'})).status,403);
});

 test('Pages can read published content, never private admin data',async()=>{
 const headers={Origin:'https://thcmae.pages.dev'};
 const publicResponse=await call('/api/public',{user:null,headers});
 assert.equal(publicResponse.headers.get('Access-Control-Allow-Origin'),headers.Origin);
 assert.equal(publicResponse.headers.get('Access-Control-Allow-Credentials'),null);
 assert.equal(publicResponse.headers.get('Cache-Control'),'no-store');
 assert.equal(publicResponse.headers.get('Vary'),'Origin');
 const admin=await call('/api/admin/state',{user:null,headers});
 assert.equal(admin.status,403);assert.equal(admin.headers.get('Access-Control-Allow-Origin'),null);
 const other=await call('/api/public',{user:null,headers:{Origin:'https://other.example'}});
 assert.equal(other.headers.get('Access-Control-Allow-Origin'),null);
 });

const multipartFiles=new Map();
env.BUCKET.createMultipartUpload=async (id)=>{const uploadId=crypto.randomUUID();multipartFiles.set(id,{uploadId,parts:new Map()});return {uploadId,abort:async()=>multipartFiles.delete(id)}};
env.BUCKET.resumeMultipartUpload=(id,uploadId)=>{const file=multipartFiles.get(id);assert.equal(file.uploadId,uploadId);return {
 async uploadPart(n,bytes){file.parts.set(n,{size:bytes.length,etag:'part-'+n});return {partNumber:n,etag:'part-'+n}},
 async complete(parts){assert.equal(parts.length,file.parts.size);let size=0;for(const part of parts){assert.equal(part.etag,file.parts.get(part.partNumber).etag);size+=file.parts.get(part.partNumber).size}file.size=size;return {size}},
 async abort(){multipartFiles.delete(id)}
}};
env.BUCKET.head=async id=>multipartFiles.get(id)?.size?{size:multipartFiles.get(id).size}:null;
test('200 MB multipart upload validates ownership, all parts, size, retry and publication boundary',async()=>{
 const size=200*1024*1024;
 assert.equal((await call('/api/admin/uploads',{user:null,method:'POST',body:{size,mime:'audio/wav'}})).status,403);
 assert.equal((await call('/api/admin/uploads',{method:'POST',body:{size:size+1,mime:'audio/wav'}})).status,413);
 const init=await call('/api/admin/uploads',{method:'POST',body:{size,mime:'audio/wav'}});assert.equal(init.status,201);const {id,partSize}=await init.json();
 assert.equal((await call('/api/admin/uploads/'+id+'/complete',{method:'POST',body:{}})).status,409);
 assert.equal((await call('/api/admin/uploads/'+id+'/complete',{user:'collaborator',method:'POST',body:{}})).status,404);
 const bytes=new Uint8Array(partSize);bytes.set(new TextEncoder().encode('RIFF1234WAVE'));
 const partCall=n=>call('/api/admin/uploads/'+id+'/parts/'+n,{method:'PUT',body:bytes,headers:{'Content-Type':'application/octet-stream'}});
 for(let n=1;n<=size/partSize;n++){const r=await partCall(n);assert.equal(r.status,200,await r.text())}
 assert.equal((await partCall(1)).status,200);
 assert.equal((await partCall(26)).status,400);
 const complete=await call('/api/admin/uploads/'+id+'/complete',{method:'POST',body:{}});assert.equal(complete.status,201,await complete.clone().text());assert.equal((await complete.json()).size,size);
 assert.equal((await call('/api/admin/uploads/'+id+'/complete',{method:'POST',body:{}})).status,200);
 assert.equal((await call('/media/'+id,{user:null})).status,404);
 const draft=await (await call('/api/admin/state')).json();draft.data.beats.push({id:crypto.randomUUID(),title:'Master WAV',genre:'',bpm:'',price:'Consultar',audio:id,cover:'',published:true,category:'mix-master'});
 assert.equal((await call('/api/admin/state',{method:'PUT',body:{data:draft.data,revision:draft.revision}})).status,200);
 await call('/api/admin/publish',{method:'POST',body:{revision:draft.revision+1}});
 const data=await (await call('/api/public',{user:null})).json();assert.equal(data.beats[0].category,'mix-master');assert.equal(data.email,'thcm4e@gmail.com');assert.equal(data.whatsapp,'528688408588');
});
test('about photo is independent, private until published, with validated palette',async()=>{
 const image=new Uint8Array([255,216,255,1,2,3,4]);const a=await (await call('/api/admin/upload',{method:'POST',headers:{'Content-Type':'image/jpeg'},body:image})).json();
 const d=await (await call('/api/admin/state')).json();const hero=d.data.cover;d.data.aboutCover=a.id;d.data.aboutPosition=70;d.data.themeAccent='#aaccee';
 assert.equal((await call('/api/admin/state',{method:'PUT',body:{data:d.data,revision:d.revision}})).status,200);
 assert.equal((await call('/media/'+a.id,{user:null})).status,404);
 await call('/api/admin/publish',{method:'POST',body:{revision:d.revision+1}});
 const p=await (await call('/api/public',{user:null})).json();assert.equal(p.cover,hero);assert.equal(p.aboutCover,a.id);assert.equal(p.aboutPosition,70);assert.equal(p.themeAccent,'#aaccee');
 const r=await call('/media/'+a.id,{user:null,headers:{Origin:'https://thcmae.pages.dev'}});assert.equal(r.status,200);assert.equal(r.headers.get('Access-Control-Allow-Origin'),'https://thcmae.pages.dev');
});

test('custom folders and individual type colors survive publishing and reject invalid data',async()=>{
 const draft=await (await call('/api/admin/state')).json();draft.data.folders.push({id:'reggaeton',name:'Reggaetón'});draft.data.textColors={hero:'#ffffff',buttons:'#ffffdd',links:'#acddff'};
 assert.equal((await call('/api/admin/state',{method:'PUT',body:{data:draft.data,revision:draft.revision}})).status,200);
 await call('/api/admin/publish',{method:'POST',body:{revision:draft.revision+1}});const p=await (await call('/api/public',{user:null})).json();assert.equal(p.folders.at(-1).name,'Reggaetón');assert.equal(p.textColors.buttons,'#ffffdd');
 draft.data.textColors.hero='red;display:none';assert.equal((await call('/api/admin/state',{method:'PUT',body:{data:draft.data,revision:draft.revision+1}})).status,400);
});
