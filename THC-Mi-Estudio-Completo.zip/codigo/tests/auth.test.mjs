import {test} from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {authRoute,passwordHash,passwordIdentity,ALLOWED_EMAILS} from '../worker/auth.mjs';
import worker from '../worker/index.mjs';
const sql=new DatabaseSync(':memory:');for(const n of readdirSync(new URL('../drizzle/',import.meta.url)).filter(n=>n.endsWith('.sql')).sort())sql.exec(readFileSync(new URL('../drizzle/'+n,import.meta.url),'utf8'));
const DB={prepare(q){const st=sql.prepare(q);let args=[];return {bind(...a){args=a;return this},async first(){return st.get(...args)||null},async run(){return {meta:{changes:Number(st.run(...args).changes)}}}}},async batch(statements){sql.exec('BEGIN');try{const r=[];for(const s of statements)r.push(await s.run());sql.exec('COMMIT');return r}catch(e){sql.exec('ROLLBACK');throw e}}};
const env={DB,AUTH_MODE:'password',BUCKET:{}},origin='https://studio.example',old='studio-private-password-2026',next='another-private-password-2026';
const request=(action,body={},cookie='',extra={})=>new Request(origin+'/api/auth/'+action,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',Cookie:cookie,...extra},body:JSON.stringify(body)});
const call=async(...args)=>{try{return await authRoute(request(...args),env)}catch(e){return Response.json({error:e.message},{status:e.status||500})}};
test('password access, chosen recovery recipient, one-use reset, change and session invalidation',async()=>{
 const initial=await passwordHash(old);sql.prepare('INSERT INTO auth_config VALUES (1,?,?,1)').run(initial.salt,initial.hash);
 assert.equal((await call('login',{email:'unapproved@example.com',password:old})).status,401);
 assert.equal((await call('login',{email:ALLOWED_EMAILS[0],password:'wrong'})).status,401);
 const cookies=[];for(const email of ALLOWED_EMAILS){const r=await call('login',{email:email.toUpperCase(),password:old});assert.equal(r.status,200);const cookie=r.headers.get('set-cookie');assert.match(cookie,/HttpOnly; Secure; SameSite=Strict/);cookies.push(cookie);assert.equal((await passwordIdentity(new Request(origin,{headers:{Cookie:cookie}}),env)).email,email)}
 assert.equal((await worker.fetch(new Request(origin+'/api/admin/state',{headers:{'oai-authenticated-user-id':'fake','oai-authenticated-user-email':ALLOWED_EMAILS[0]}}),env)).status,403);
 assert.equal((await call('change',{current:old,password:next},cookies[0],{Origin:'https://evil.example'})).status,403);
 assert.equal((await call('recover',{email:ALLOWED_EMAILS[1]})).status,503);
 env.RESEND_API_KEY='test';env.MAIL_FROM='test@example.com';const realFetch=globalThis.fetch;let sent;
 globalThis.fetch=async(url,opts)=>{assert.equal(url,'https://api.resend.com/emails');sent=JSON.parse(opts.body);return Response.json({id:'test-message'})};
 try{
  const recovered=await call('recover',{email:ALLOWED_EMAILS[2]});assert.equal(recovered.status,200);assert.deepEqual(sent.to,[ALLOWED_EMAILS[2]]);const token=sent.text.match(/#reset=([a-f0-9]+)/)[1];
  assert.equal((await call('reset',{token:'0'.repeat(64),password:next})).status,400);
  const resets=await Promise.all([call('reset',{token,password:next}),call('reset',{token,password:next})]);assert.equal(resets.filter(r=>r.status===200).length,1);
  assert.equal(await passwordIdentity(new Request(origin,{headers:{Cookie:cookies[0]}}),env),null);
  assert.equal((await call('login',{email:ALLOWED_EMAILS[0],password:old})).status,401);
  const login=await call('login',{email:ALLOWED_EMAILS[0],password:next});assert.equal(login.status,200);const cookie=login.headers.get('set-cookie');
  assert.equal((await call('change',{current:'wrong',password:old},cookie)).status,401);
  assert.equal((await call('change',{current:next,password:old},cookie)).status,200);
  assert.equal(await passwordIdentity(new Request(origin,{headers:{Cookie:cookie}}),env),null);
  await call('recover',{email:ALLOWED_EMAILS[1]});const expired=sent.text.match(/#reset=([a-f0-9]+)/)[1];sql.prepare('UPDATE auth_resets SET expires = 0').run();assert.equal((await call('reset',{token:expired,password:next})).status,400);
  const rateResults=[];for(let i=0;i<10;i++)rateResults.push((await call('login',{email:ALLOWED_EMAILS[1],password:'bad'})).status);assert.ok(rateResults.includes(429));
 }finally{globalThis.fetch=realFetch}
});
