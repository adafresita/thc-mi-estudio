CREATE TABLE `cms_assets` (
	`id` text PRIMARY KEY NOT NULL,
	`mime` text NOT NULL,
	`size` integer NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `cms_editors` (
	`email` text PRIMARY KEY NOT NULL,
	`user_id` text
);
--> statement-breakpoint
CREATE TABLE `cms_state` (
	`id` text PRIMARY KEY NOT NULL,
	`data` text NOT NULL,
	`revision` integer DEFAULT 1 NOT NULL
);
