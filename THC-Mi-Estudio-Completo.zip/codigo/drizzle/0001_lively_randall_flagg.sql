CREATE TABLE `cms_uploads` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`upload_id` text NOT NULL,
	`mime` text NOT NULL,
	`size` integer NOT NULL,
	`created` integer NOT NULL,
	`parts` text DEFAULT '{}' NOT NULL,
	`status` text DEFAULT 'open' NOT NULL
);
