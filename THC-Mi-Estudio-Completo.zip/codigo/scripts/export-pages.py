"""Export the public Pages frontend; content stays in the protected CMS."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import sys
root = Path(__file__).resolve().parent.parent
origin = 'https://thc-sound-studio.bleuarchivee.chatgpt.site'
out = Path(sys.argv[1]).resolve()
with ZipFile(out, 'w', ZIP_DEFLATED) as z:
    for name in ['index.html', 'style.css', 'script.js', 'theme.js', 'assets/thc-portrait.jpg', 'assets/thc-identity.png']:
        content = (root / 'public' / name).read_bytes()
        if name == 'index.html':
            content = content.decode().replace('<head>', '<head>\n<meta name="thc-content-origin" content="'+origin+'">').encode()
        z.writestr(name, content)
    z.writestr('_redirects', '\n'.join(f'{path} {origin}{dest} 302' for path,dest in [('/admin','/admin'),('/admin/','/admin'),('/admin.html','/admin'),('/preview','/preview')])+'\n')
    z.writestr('_headers', '/*\n  Cache-Control: no-cache\n  X-Content-Type-Options: nosniff\n  Referrer-Policy: strict-origin-when-cross-origin\n')
print(out)
