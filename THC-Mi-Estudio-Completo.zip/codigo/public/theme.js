// Derive restrained, readable accents from the cover, while keeping a charcoal canvas.
window.THCTheme={
 applyText(colors={}){for(const key of ['hero','heroAccent','headings','body','muted','links','buttons']){const color=colors?.[key];if(/^#[0-9a-f]{6}$/i.test(color||''))document.documentElement.style.setProperty('--text-'+key,color);else document.documentElement.style.removeProperty('--text-'+key)}},
 apply(hex){if(!/^#[0-9a-f]{6}$/i.test(hex||''))return;document.documentElement.style.setProperty('--accent',hex);document.documentElement.style.setProperty('--amber',hex)},
 async extract(source){
  const img=typeof source==='string'?new Image():source;
  if(typeof source==='string'){img.crossOrigin='anonymous';img.src=source}
  await img.decode();const c=document.createElement('canvas');c.width=c.height=48;const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(img,0,0,48,48);
  const px=ctx.getImageData(0,0,48,48).data,bins=new Map();
  for(let i=0;i<px.length;i+=4){const r=px[i],g=px[i+1],b=px[i+2],max=Math.max(r,g,b),min=Math.min(r,g,b);if(px[i+3]<128||max<40||min>225||max-min<20)continue;const key=[r,g,b].map(v=>Math.floor(v/32)).join(',');const v=bins.get(key)||{n:0,r:0,g:0,b:0};v.n++;v.r+=r;v.g+=g;v.b+=b;bins.set(key,v)}
  const v=[...bins.values()].sort((a,b)=>b.n-a.n)[0];if(!v)return '#b9c5cf';
  let rgb=[v.r/v.n,v.g/v.n,v.b/v.n];const lum=a=>a.map(x=>x/255).map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4).reduce((s,x,i)=>s+x*[.2126,.7152,.0722][i],0);
  while(lum(rgb)<.46)rgb=rgb.map(x=>x+(255-x)*.08);
  return '#'+rgb.map(x=>Math.round(x).toString(16).padStart(2,'0')).join('');
 }
};
