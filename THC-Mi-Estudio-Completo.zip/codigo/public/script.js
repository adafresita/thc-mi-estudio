const q=s=>document.querySelector(s);
const wave=q('.wave');for(let i=0;i<28;i++){const bar=document.createElement('i');bar.style.height=(8+Math.abs(Math.sin(i*.7)*Math.cos(i*.23))*36)+'px';wave.appendChild(bar)}
let content,activeFolder='beats';
let folderIds=['beats','grabaciones','mix-master'];
const apiOrigin=q('meta[name="thc-content-origin"]')?.content||'';
const remote=!!apiOrigin,preview=!remote&&location.pathname==='/preview';
const mediaUrl=id=>apiOrigin+'/media/'+encodeURIComponent(id);
const whatsapp=message=>'https://wa.me/'+(content?.whatsapp||'528688408588')+'?text='+encodeURIComponent(message);
q('#brief').addEventListener('submit',event=>{event.preventDefault();const service=q('#service').value,idea=q('#idea').value.trim();const message=`Hola ${content?.name||'THC'}, me interesa ${service.toLowerCase()}.${idea?' Mi idea: '+idea:''} ¿Podrías compartirme disponibilidad y cotización?`;location.href=whatsapp(message)});
function folderName(id){return content?.folders?.find(f=>f.id===id)?.name||content?.services[folderIds.indexOf(id)]?.name||id}
function renderFolder(id,focus=false){
 if(!content||!folderIds.includes(id))return;activeFolder=id;
 q('#beat-catalog').hidden=false;q('#folder-title').textContent=folderName(id);
 document.querySelectorAll('[data-folder]').forEach(b=>{b.classList.toggle('active',b.dataset.folder===id);b.setAttribute('aria-pressed',String(b.dataset.folder===id))});
 const beats=content.beats.filter(b=>b.published&&(b.category||'beats')===id),list=q('#public-beats');
 list.querySelectorAll('audio').forEach(a=>a.pause());list.replaceChildren();q('#folder-count').textContent=beats.length?`${beats.length} ${beats.length===1?'archivo disponible':'archivos disponibles'}`:'Todavía no hay archivos publicados en esta carpeta.';
 if(!beats.length){const a=document.createElement('a');a.className='button';a.href=whatsapp('Hola '+content.name+', me interesa '+folderName(id).toLowerCase()+'. ¿Podemos trabajar juntos?');a.textContent='Consultar por WhatsApp';a.target='_blank';a.rel='noopener noreferrer';list.append(a)}
 beats.forEach(b=>{
 const card=document.createElement('article');card.className='public-beat';
 if(b.cover){const img=document.createElement('img');img.src=mediaUrl(b.cover);img.alt='Portada de '+b.title;img.loading='lazy';card.append(img)}
 const info=document.createElement('div');info.className='beat-info';const name=document.createElement('h3');name.textContent=b.title;
 const meta=document.createElement('p');meta.textContent=[b.genre,b.bpm?b.bpm+' BPM':'',b.price].filter(Boolean).join(' · ');
 const audio=document.createElement('audio');audio.controls=true;audio.preload='none';audio.src=mediaUrl(b.audio);audio.setAttribute('aria-label','Escuchar '+b.title);audio.addEventListener('play',()=>document.querySelectorAll('audio').forEach(other=>{if(other!==audio)other.pause()}));
 const link=document.createElement('a');link.href=whatsapp('Hola '+content.name+', me interesa “'+b.title+'” de '+folderName(id)+'.');link.target='_blank';link.rel='noopener noreferrer';link.textContent='Preguntar por WhatsApp';info.append(name,meta,audio,link);card.append(info);list.append(card);
 });
 if(focus){q('#beat-catalog').scrollIntoView({behavior:'smooth',block:'start'});q('#beat-catalog').focus({preventScroll:true})}
}
function hashFolder(){const id=location.hash.replace('#carpeta-','');if(folderIds.includes(id))renderFolder(id,true)}
window.addEventListener('hashchange',hashFolder);
document.querySelectorAll('[data-folder]').forEach(b=>b.onclick=()=>{location.hash='carpeta-'+b.dataset.folder;if(activeFolder===b.dataset.folder)renderFolder(activeFolder,true)});
document.querySelectorAll('[data-folder-link]').forEach(a=>a.addEventListener('click',()=>{if(content)q('#service').value=folderName(a.dataset.folderLink);if(location.hash===a.hash)renderFolder(a.dataset.folderLink,true)}));
async function setPhoto(img,src,position){img.crossOrigin='anonymous';img.style.objectPosition=`center ${position}%`;img.src=src;try{await img.decode()}catch{img.removeAttribute('crossorigin');img.src=src}img.classList.add('photo-ready')}
async function loadContent(draft){
 const note=q('#load-note')||document.createElement('div');note.id='load-note';note.className='site-note';note.setAttribute('role','status');
 try{
 let result;if(preview&&draft?.headline){result={data:draft}}else{const response=await fetch(apiOrigin+(preview?'/api/admin/state':'/api/public'),{cache:'no-store',credentials:remote?'omit':'same-origin',signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error();result=await response.json();}content=preview?result.data:result;
 const data=content,put=(s,t)=>{const el=q(s);if(el)el.textContent=t};document.title=data.name+' — Productor musical';
 q('h1').replaceChildren();data.headline.split('\n').forEach((line,i,lines)=>{if(i)q('h1').append(document.createElement('br'));const el=document.createElement(i===lines.length-1?'em':'span');el.textContent=line;q('h1').append(el)});
 put('.intro',data.intro);q('.intro').style.whiteSpace='pre-line';put('.about-copy h2',`SOY ${data.name}.`);
 const bio=document.querySelectorAll('.about-copy>p');bio[0].textContent=data.bio;bio[1].textContent=data.credits;
 put('.hero-bottom>span:nth-child(2)',data.location);put('.contact-handle',`@${data.instagram.toUpperCase()} / ${data.location}`);
 const insta='https://www.instagram.com/'+encodeURIComponent(data.instagram)+'/';document.querySelectorAll('a[href*="instagram.com"]').forEach(a=>a.href=insta);
 put('.about-copy .text-link','EL PROCESO, EN @'+data.instagram.toUpperCase());put('.photo-caption',data.name+' / FUERA DEL ESTUDIO');
 const heroSrc=data.cover?mediaUrl(data.cover):'/assets/thc-portrait.jpg';
 const hero=q('.hero-photo');hero.alt='Retrato de '+data.name;const photo=setPhoto(hero,heroSrc,data.coverPosition);
 const about=q('.about-photo img');about.alt=data.name+' fuera del estudio';setPhoto(about,data.aboutCover?mediaUrl(data.aboutCover):'/assets/thc-portrait.jpg',data.aboutPosition??50);
 THCTheme.apply(data.themeAccent);THCTheme.applyText(data.textColors);
 photo.then(async()=>{try{const color=data.themeAccent||await THCTheme.extract(hero);THCTheme.apply(color)}catch{}});
 document.querySelectorAll('.service').forEach((el,i)=>{el.querySelector('h3').textContent=data.services[i].name;el.querySelector('p').textContent=data.services[i].description;el.dataset.service=data.services[i].name});
 data.folders=data.folders||folderIds.map((id,i)=>({id,name:data.services[i].name}));folderIds=data.folders.map(f=>f.id);
 const tabs=q('.folder-tabs');tabs.replaceChildren();data.folders.forEach(f=>{const b=document.createElement('button');b.type='button';b.dataset.folder=f.id;b.textContent=f.name;b.onclick=()=>{location.hash='carpeta-'+f.id;renderFolder(f.id,true)};tabs.append(b)});
 q('#service').replaceChildren(...[...data.services.map(s=>s.name),'Producción completa'].map(name=>{const option=document.createElement('option');option.textContent=name;return option}));
 if(data.playlist){const id=new URL(data.playlist).pathname.split('/').pop();q('.player iframe').src='https://open.spotify.com/embed/playlist/'+id+'?theme=0';document.querySelectorAll('a[href*="open.spotify.com"]').forEach(a=>a.href=data.playlist)}else{q('.player').hidden=true;q('.work-copy>.text-link').hidden=true}
 q('#whatsapp-link').href=whatsapp('Hola '+data.name+', quiero trabajar contigo.');q('#instagram-link').href=insta;q('#email-link').href='mailto:'+(data.email||'thcm4e@gmail.com');
 renderFolder(folderIds.includes(location.hash.replace('#carpeta-',''))?location.hash.replace('#carpeta-',''):'beats');
 document.body.classList.remove('content-loading');q('.load-caption').hidden=true;q('main').hidden=false;
 note.remove();if(preview){note.textContent='VISTA PREVIA · Borrador guardado. Estos cambios todavía pueden no estar publicados.';document.body.prepend(note)}
 if(!remote){fetch('/api/admin/state').then(r=>{if(r.ok)q('#admin-link').hidden=false}).catch(()=>{})}
 if(location.hash.startsWith('#carpeta-'))hashFolder();
 }catch{
 document.body.classList.remove('content-loading');q('.load-caption').hidden=true;note.replaceChildren(document.createTextNode('No pudimos cargar el contenido actualizado. '));const retry=document.createElement('button');retry.textContent='Volver a intentar';retry.onclick=loadContent;note.append(retry);document.body.prepend(note);if(preview)q('main').hidden=true;
 }
}
window.addEventListener('message',e=>{if(preview&&e.origin===location.origin&&e.source===parent&&e.data?.type==='thc-preview')loadContent(e.data.data)});
loadContent();
