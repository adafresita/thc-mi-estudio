export const STATIC = {};
