import { passwordIdentity, authRoute, ALLOWED_EMAILS } from './auth.mjs';
import { DEFAULTS } from './defaults.mjs';
import { STATIC } from './static.mjs';
const j=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const fail=(message,status=400)=>{throw Object.assign(new Error(message),{status})};
const db=env=>{if(!env.DB||!env.BUCKET)fail('El almacenamiento no está disponible. Intenta de nuevo más tarde.',503);return env.DB};
async function identity(req,env){
 if(env.AUTH_MODE==='password')return passwordIdentity(req,env);

 const uid=req.headers.get('oai-authenticated-user-id'),email=req.headers.get('oai-authenticated-user-email')?.trim().toLowerCase();
 if(!uid||!email||!ALLOWED_EMAILS.includes(email))return null;
 const owner=!!env.CMS_OWNER_EMAIL&&email===env.CMS_OWNER_EMAIL.toLowerCase();
 let row=await db(env).prepare('SELECT user_id FROM cms_editors WHERE email = ?').bind(email).first();
 // The three studio addresses are explicitly authorized.
 // Link each approved address to the stable Site-scoped identity on first sign-in.
 if(!row){await db(env).prepare('INSERT OR IGNORE INTO cms_editors (email,user_id) VALUES (?,?)').bind(email,uid).run();}
 else if(!row.user_id){await db(env).prepare('UPDATE cms_editors SET user_id = ? WHERE email = ? AND user_id IS NULL').bind(uid,email).run();}
 row=await db(env).prepare('SELECT user_id FROM cms_editors WHERE email = ?').bind(email).first();
 return row?.user_id===uid?{email,owner}:null;
}
function normalize(data){return {...structuredClone(DEFAULTS),...data,folders:data.folders||DEFAULTS.folders.map((f,i)=>({...f,name:data.services?.[i]?.name||f.name})),textColors:data.textColors||{},beats:(data.beats||[]).map(b=>({...b,category:b.category||'beats'}))}}
async function readState(env,id){const row=await db(env).prepare('SELECT data,revision FROM cms_state WHERE id = ?').bind(id).first();return row?{data:normalize(JSON.parse(row.data)),revision:row.revision}:{data:structuredClone(DEFAULTS),revision:0}}
function visible(data){return {...data,beats:data.beats.filter(b=>b.published)}}
function refs(data){return [data.cover,data.aboutCover,...data.beats.flatMap(b=>[b.audio,b.cover])].filter(Boolean)}
function str(v,n=500){if(typeof v!=='string'||v.length>n)fail('Revisa los campos: hay texto demasiado largo o inválido.');return v.trim()}
function valid(data){
 if(!data||typeof data!=='object')fail('Datos inválidos.');
 data=normalize(data);const o={};
 if(!Array.isArray(data.folders)||data.folders.length<3||data.folders.length>30)fail('Usa entre 3 y 30 carpetas.');
 const folderIds=new Set();o.folders=data.folders.map(f=>{const id=str(f.id,50),name=str(f.name,60);if(!/^[a-z0-9-]{1,50}$/.test(id)||!name||folderIds.has(id))fail('Revisa los nombres de las carpetas.');folderIds.add(id);return {id,name}});
 if(['beats','grabaciones','mix-master'].some(id=>!folderIds.has(id)))fail('Conserva las tres carpetas de servicios.');
 o.textColors={};for(const k of ['hero','heroAccent','headings','body','muted','links','buttons']){const color=data.textColors?.[k];if(color){if(!/^#[a-fA-F0-9]{6}$/.test(color))fail('Color de texto inválido.');o.textColors[k]=color}}
for(const [k,n]of Object.entries({name:60,headline:150,intro:350,bio:2000,credits:2000,location:120,instagram:30,playlist:200,cover:36,aboutCover:36,whatsapp:20,email:254,themeAccent:7}))o[k]=str(data[k],n);
 if(!o.name||!o.headline||!/^[a-zA-Z0-9._]{1,30}$/.test(o.instagram))fail('Escribe un nombre, un título y un usuario de Instagram válido.');
 if(o.playlist&&!/^https:\/\/open\.spotify\.com\/playlist\/[a-zA-Z0-9]+(?:\?[^\s]*)?$/.test(o.playlist))fail('Usa el enlace de una playlist de Spotify.');
 if(!/^\d{8,15}$/.test(o.whatsapp)||!/^([^\s@]+)@([^\s@]+)\.([^\s@]+)$/.test(o.email))fail('Revisa tu WhatsApp y correo de contacto.');
 if(o.themeAccent&&!/^#[a-fA-F0-9]{6}$/.test(o.themeAccent))fail('Color inválido.');
 o.aboutPosition=Number(data.aboutPosition);if(!Number.isFinite(o.aboutPosition)||o.aboutPosition<0||o.aboutPosition>100)fail('Encuadre inválido.');
 o.coverPosition=Number(data.coverPosition);if(!Number.isFinite(o.coverPosition)||o.coverPosition<0||o.coverPosition>100)fail('Encuadre inválido.');
 if(!Array.isArray(data.services)||data.services.length!==3)fail('Se requieren tres servicios.');
 o.services=data.services.map(s=>({name:str(s.name,60),description:str(s.description,600)}));
 if(!Array.isArray(data.beats)||data.beats.length>100)fail('El catálogo admite hasta 100 beats.');
 const ids=new Set();o.beats=data.beats.map(b=>{const id=str(b.id,36);if(!/^[a-f0-9-]{36}$/.test(id)||ids.has(id))fail('Identificador de beat inválido.');ids.add(id);const beat={id,title:str(b.title,100),genre:str(b.genre,80),bpm:str(b.bpm,3),price:str(b.price,60),audio:str(b.audio,36),cover:str(b.cover,36),published:b.published===true,category:b.category||'beats'};if(!folderIds.has(beat.category))fail('Carpeta inválida.');if(!beat.title||!beat.audio||beat.bpm&&!/^\d{1,3}$/.test(beat.bpm))fail('Cada beat necesita título, audio y un BPM válido (o vacío).');return beat});
 if(refs(o).some(x=>!/^[a-f0-9-]{36}$/.test(x)))fail('Archivo inválido.');return o;
}
async function jsonBody(req){if(Number(req.headers.get('content-length'))>180000)fail('Contenido demasiado grande.',413);const raw=await req.text();if(raw.length>180000)fail('Contenido demasiado grande.',413);try{return JSON.parse(raw)}catch{fail('No se pudo leer el formulario.')}}
async function checkAssets(env,data){for(const [id,type]of [[data.cover,'image/'],[data.aboutCover,'image/'],...data.beats.flatMap(b=>[[b.audio,'audio/'],[b.cover,'image/']])]){if(!id)continue;const a=await db(env).prepare('SELECT mime FROM cms_assets WHERE id = ?').bind(id).first();if(!a||!a.mime.startsWith(type))fail('Falta un archivo. Vuelve a subirlo antes de guardar.')}}
async function upload(req,env){
 const type=req.headers.get('content-type')?.split(';')[0];const allowed=['image/jpeg','image/png','image/webp','audio/mpeg','audio/wav','audio/x-wav'];if(!allowed.includes(type))fail('Usa JPG, PNG, WebP, MP3 o WAV.',415);
 const limit=type.startsWith('image/')?8*1024*1024:25*1024*1024;if(Number(req.headers.get('content-length'))>limit)fail('El archivo supera el límite permitido.',413);
 const reader=req.body?.getReader();if(!reader)fail('Archivo vacío.');let size=0;const chunks=[];while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>limit){await reader.cancel();fail('El archivo supera el límite permitido.',413)}chunks.push(value)}if(!size)fail('Archivo vacío.');
 const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length}const sig=String.fromCharCode(...bytes.slice(0,12));
 const ok=type==='image/jpeg'?bytes[0]===255&&bytes[1]===216&&bytes[2]===255:type==='image/png'?bytes[0]===137&&sig.slice(1,4)==='PNG':type==='image/webp'?sig.startsWith('RIFF')&&sig.slice(8,12)==='WEBP':type==='audio/mpeg'?sig.startsWith('ID3')||(bytes[0]===255&&(bytes[1]&224)===224):sig.startsWith('RIFF')&&sig.slice(8,12)==='WAVE';if(!ok)fail('El contenido no coincide con el tipo de archivo.',415);
 const id=crypto.randomUUID();await env.BUCKET.put(id,bytes,{httpMetadata:{contentType:type}});try{await db(env).prepare('INSERT INTO cms_assets (id,mime,size,created) VALUES (?,?,?,?)').bind(id,type,size,new Date().toISOString()).run()}catch(e){await env.BUCKET.delete(id);throw e}return j({id,size,mime:type},201);
}
const PART_SIZE=8*1024*1024,MAX_AUDIO=200*1024*1024;
async function boundedBytes(req,limit){
 if(Number(req.headers.get('content-length'))>limit)fail('El fragmento supera el tamaño permitido.',413);
 const reader=req.body?.getReader();if(!reader)fail('Archivo vacío.');const chunks=[];let size=0;
 while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>limit){await reader.cancel();fail('El fragmento supera el tamaño permitido.',413)}chunks.push(value)}
 const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length}return bytes;
}
async function multipart(req,env,user){
 const url=new URL(req.url),path=url.pathname.split('/').filter(Boolean);
 if(path.length===3&&req.method==='POST'){
  const b=await jsonBody(req);if(!['audio/mpeg','audio/wav','audio/x-wav'].includes(b.mime))fail('Elige un audio MP3 o WAV.',415);
  if(!Number.isSafeInteger(b.size)||b.size<1||b.size>MAX_AUDIO)fail('El audio debe pesar como máximo 200 MB.',413);
  const id=crypto.randomUUID(),upload=await env.BUCKET.createMultipartUpload(id,{httpMetadata:{contentType:b.mime}});
  try{await db(env).prepare('INSERT INTO cms_uploads (id,owner,upload_id,mime,size,created) VALUES (?,?,?,?,?,?)').bind(id,user.email,upload.uploadId,b.mime,b.size,Date.now()).run()}catch(e){await upload.abort();throw e}
  return j({id,partSize:PART_SIZE},201);
 }
 const id=path[3];if(!/^[a-f0-9-]{36}$/.test(id||''))fail('Carga no encontrada.',404);
 const row=await db(env).prepare('SELECT * FROM cms_uploads WHERE id = ? AND owner = ?').bind(id,user.email).first();if(!row)fail('Carga no encontrada.',404);
 if(req.method==='POST'&&path[4]==='complete'&&row.status==='complete')return j({id,size:row.size,mime:row.mime});
 if(Date.now()-row.created>24*60*60*1000)fail('La carga venció. Selecciona el archivo de nuevo.',410);
 const upload=env.BUCKET.resumeMultipartUpload(id,row.upload_id);
 if(req.method==='DELETE'&&path.length===4){if(row.status!=='open')fail('La carga ya está finalizando.',409);await upload.abort();await db(env).prepare('DELETE FROM cms_uploads WHERE id = ? AND owner = ?').bind(id,user.email).run();return j({ok:true})}
 const count=Math.ceil(row.size/PART_SIZE);
 if(req.method==='PUT'&&path[4]==='parts'&&path.length===6){
  if(row.status!=='open')fail('La carga ya está finalizando.',409);
  const n=Number(path[5]);if(!Number.isInteger(n)||n<1||n>count)fail('Fragmento inválido.');
  const expected=n===count?row.size-PART_SIZE*(count-1):PART_SIZE;
  const bytes=await boundedBytes(req,expected);if(bytes.length!==expected)fail('El fragmento llegó incompleto. Intenta de nuevo.');
  if(n===1){const sig=String.fromCharCode(...bytes.slice(0,12));const ok=row.mime==='audio/mpeg'?sig.startsWith('ID3')||(bytes[0]===255&&(bytes[1]&224)===224):sig.startsWith('RIFF')&&sig.slice(8,12)==='WAVE';if(!ok)fail('El archivo no es un MP3 o WAV válido.',415)}
  const part=await upload.uploadPart(n,bytes);
  await db(env).prepare('UPDATE cms_uploads SET parts = json_set(parts, ?, json(?)) WHERE id = ? AND status = ?').bind('$."'+n+'"',JSON.stringify({partNumber:n,etag:part.etag}),id,'open').run();
  return j({partNumber:n});
 }
 if(req.method==='POST'&&path[4]==='complete'&&path.length===5){
  const parts=JSON.parse(row.parts),ordered=Array.from({length:count},(_,i)=>parts[i+1]);if(ordered.some(p=>!p))fail('Faltan fragmentos por subir.',409);
  // A retry can recover completion if the response or metadata write was interrupted.
  let object=await env.BUCKET.head(id);
  if(!object){const claim=await db(env).prepare("UPDATE cms_uploads SET status = 'finishing' WHERE id = ? AND status = 'open'").bind(id).run();if(!claim.meta.changes)fail('El archivo está finalizando. Intenta de nuevo.',409);
   try{object=await upload.complete(ordered)}catch(e){await db(env).prepare("UPDATE cms_uploads SET status = 'open' WHERE id = ? AND status = 'finishing'").bind(id).run();throw e}
  }
  if(object.size!==row.size)fail('El tamaño final no coincide. Vuelve a subir el archivo.',409);
  await db(env).prepare('INSERT OR IGNORE INTO cms_assets (id,mime,size,created) VALUES (?,?,?,?)').bind(id,row.mime,row.size,new Date().toISOString()).run();
  await db(env).prepare("UPDATE cms_uploads SET status = 'complete' WHERE id = ?").bind(id).run();return j({id,size:row.size,mime:row.mime},201);
 }
 return j({error:'Ruta no encontrada.'},404);
}

async function media(req,env,id){
 if(!/^[a-f0-9-]{36}$/.test(id))return j({error:'Archivo no encontrado.'},404);
 const data=visible((await readState(env,'published')).data);const isPublic=refs(data).includes(id);if(!isPublic&&!await identity(req,env))return j({error:'Archivo no encontrado.'},404);
 const info=await db(env).prepare('SELECT mime,size FROM cms_assets WHERE id = ?').bind(id).first();if(!info)return j({error:'Archivo no encontrado.'},404);
 const headers={'Content-Type':info.mime,'Content-Length':String(info.size),'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Accept-Ranges':'bytes'};
 if(isPublic&&req.headers.get('Origin')==='https://thcmae.pages.dev'){headers['Access-Control-Allow-Origin']='https://thcmae.pages.dev';headers.Vary='Origin'}
 if(req.method==='HEAD')return new Response(null,{headers});
 let range;const r=req.headers.get('range');if(r){const m=/^bytes=(\d*)-(\d*)$/.exec(r);if(!m||(!m[1]&&!m[2]))return new Response(null,{status:416,headers:{'Content-Range':`bytes */${info.size}`}});let start=m[1]?Number(m[1]):Math.max(0,info.size-Number(m[2]));let end=m[1]?(m[2]?Math.min(Number(m[2]),info.size-1):info.size-1):info.size-1;if(start>end||start>=info.size)return new Response(null,{status:416,headers:{'Content-Range':`bytes */${info.size}`}});range={offset:start,length:end-start+1};headers['Content-Range']=`bytes ${start}-${end}/${info.size}`;headers['Content-Length']=String(range.length)}
 let object=await env.BUCKET.get(id,range?{range}:undefined);const embedded=STATIC['/media/'+id];if(!object&&embedded){let bytes=Uint8Array.from(atob(embedded.body),c=>c.charCodeAt(0));if(range)bytes=bytes.slice(range.offset,range.offset+range.length);object={body:bytes}}return object?new Response(object.body,{status:range?206:200,headers}):j({error:'Archivo no encontrado.'},404);
}
export default {async fetch(req,env){try{
 const url=new URL(req.url),p=url.pathname,method=req.method;
 if(p.startsWith('/api/auth/'))return await authRoute(req,env);
 if(!['GET','HEAD','POST','PUT','DELETE'].includes(method))return j({error:'Método no permitido.'},405);
 if(!['GET','HEAD'].includes(method)){if(req.headers.get('origin')!==url.origin||req.headers.get('sec-fetch-site')==='cross-site')return j({error:'Solicitud no autorizada.'},403)}
 if(p==='/api/public'&&method==='GET'){
  const response=j(visible((await readState(env,'published')).data));
  response.headers.set('Vary','Origin');
  if(req.headers.get('Origin')==='https://thcmae.pages.dev')response.headers.set('Access-Control-Allow-Origin','https://thcmae.pages.dev');
  return response;
 }
 if(p.startsWith('/media/')&&['GET','HEAD'].includes(method))return await media(req,env,p.slice(7));
 if(p==='/admin'||p==='/admin/'||p==='/admin.html'||p==='/preview'||p.startsWith('/api/admin/')){
  const user=await identity(req,env);if(!user){if(p.startsWith('/api/'))return j({error:'Inicia sesión con una cuenta autorizada.'},403);if(env.AUTH_MODE==='password')return Response.redirect(url.origin+'/login',302);if(!req.headers.get('oai-authenticated-user-id'))return Response.redirect(url.origin+'/signin-with-chatgpt?return_to='+encodeURIComponent('/admin'),302);return new Response('<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Acceso restringido</title><body style="font:18px Arial;padding:10%;background:#102f2b;color:#f0ecdf"><h1>Este panel es privado.</h1><p>Tu cuenta no está autorizada para editar este sitio.</p><a style="color:#e4ac63" href="/signout-with-chatgpt?return_to=%2Fadmin">Cambiar de cuenta</a> · <a style="color:#e4ac63" href="/">Volver a la página</a></body></html>',{status:403,headers:{'Content-Type':'text/html;charset=utf-8','Cache-Control':'no-store'}})}
  if(p==='/api/admin/state'&&method==='GET'){const draft=await readState(env,'draft');return j({...draft,user,studioEmail:env.CMS_OWNER_EMAIL,authMode:env.AUTH_MODE||'platform'})}
  if(p==='/api/admin/state'&&method==='PUT'){const b=await jsonBody(req),data=valid(b.data);await checkAssets(env,data);const current=await readState(env,'draft');if(b.revision!==current.revision)fail('Otra persona guardó cambios. Recarga el panel antes de continuar.',409);const result=await db(env).prepare('INSERT INTO cms_state (id,data,revision) VALUES (?,?,1) ON CONFLICT(id) DO UPDATE SET data = excluded.data, revision = cms_state.revision + 1 WHERE cms_state.revision = ?').bind('draft',JSON.stringify(data),b.revision).run();if(!result.meta.changes)fail('Otra persona guardó cambios. Recarga el panel.',409);return j({revision:b.revision+1})}
  if(p==='/api/admin/publish'&&method==='POST'){const b=await jsonBody(req),d=await readState(env,'draft');if(!d.revision||d.revision!==b.revision)fail('Guarda el borrador actualizado antes de publicar.',409);await checkAssets(env,d.data);const result=await db(env).prepare("INSERT INTO cms_state (id,data,revision) SELECT 'published',data,revision FROM cms_state WHERE id = 'draft' AND revision = ? ON CONFLICT(id) DO UPDATE SET data = excluded.data, revision = excluded.revision").bind(b.revision).run();if(!result.meta.changes)fail('El borrador cambió. Recarga antes de publicar.',409);return j({published:true})}
  if(p.startsWith('/api/admin/uploads'))return await multipart(req,env,user);
  if(p==='/api/admin/upload'&&method==='POST')return await upload(req,env);
  if(p==='/api/admin/editors'){if(method==='GET')return j(ALLOWED_EMAILS.map(email=>({email})));return j({error:'Los accesos están limitados a los tres correos del estudio.'},403)}
  if(p.startsWith('/api/'))return j({error:'Ruta no encontrada.'},404);
 }
 if(p.startsWith('/api/'))return j({error:'Ruta no encontrada.'},404);
 if(!['GET','HEAD'].includes(method))return j({error:'Método no permitido.'},405);
 const path=p==='/login'?'/login.html':p==='/admin'||p==='/admin/'?'/admin.html':p==='/'||p==='/preview'?'/index.html':p;
 const asset=STATIC[path];if(!asset)return new Response('No encontrado',{status:404});
 const body=asset.encoding==='base64'?Uint8Array.from(atob(asset.body),c=>c.charCodeAt(0)):asset.body;
 return new Response(method==='HEAD'?null:body,{headers:{'Content-Type':asset.type,'Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'strict-origin-when-cross-origin','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' blob: data:; media-src 'self' blob:; frame-src https://open.spotify.com; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'self' https://chatgpt.com"}});
 }catch(e){if(!e.status)console.error('CMS request failed',e.message);return j({error:e.status?e.message:'No se pudo guardar o cargar la información. Tus cambios siguen en el formulario; intenta de nuevo.'},e.status||503)}}};
