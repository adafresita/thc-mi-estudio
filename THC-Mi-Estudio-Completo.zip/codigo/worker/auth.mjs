// Standalone Cloudflare authentication; never trusts platform headers in password mode.
export const ALLOWED_EMAILS=['adaleisha.castro.20@gmail.com','thcm4e@gmail.com','risaiaguayo@gmail.com'];
const authJSON=(body,status=200,headers={})=>Response.json(body,{status,headers:{'Cache-Control':'no-store',...headers}});
const authFail=(message,status=400)=>{throw Object.assign(new Error(message),{status})};
const hex=b=>Array.from(new Uint8Array(b),x=>x.toString(16).padStart(2,'0')).join('');
const randomToken=()=>hex(crypto.getRandomValues(new Uint8Array(32)));
const digest=async s=>hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
const cookie=(token,age=43200)=>`__Host-thc-session=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${age}`;
const sessionToken=req=>req.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith('__Host-thc-session='))?.split('=')[1]||'';
const passwordOK=p=>typeof p==='string'&&p.length>=16&&p.length<=128;
export async function passwordHash(password,salt=randomToken()){
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(password),'PBKDF2',false,['deriveBits']);
 const hash=hex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:new TextEncoder().encode(salt),iterations:100000},key,256));
 return {salt,hash};
}
async function matches(password,config){if(typeof password!=='string'||password.length>128)return false;const actual=(await passwordHash(password,config.salt)).hash;let n=actual.length^config.hash.length;for(let i=0;i<actual.length;i++)n|=actual.charCodeAt(i)^(config.hash.charCodeAt(i)||0);return n===0}
export async function passwordIdentity(req,env){
 const token=sessionToken(req);if(!/^[a-f0-9]{64}$/.test(token))return null;
 const row=await env.DB.prepare('SELECT s.email FROM auth_sessions s JOIN auth_config c ON c.id = 1 AND c.version = s.version WHERE s.token = ? AND s.expires > ?').bind(await digest(token),Date.now()).first();
 return row&&ALLOWED_EMAILS.includes(row.email)?{email:row.email,owner:true}:null;
}
async function rate(env,key,limit,window=900000){
 const bucket=Math.floor(Date.now()/window),id=await digest(key+':'+bucket);
 await env.DB.prepare('INSERT INTO auth_limits (id,count,expires) VALUES (?,1,?) ON CONFLICT(id) DO UPDATE SET count = count + 1').bind(id,(bucket+1)*window).run();
 const row=await env.DB.prepare('SELECT count FROM auth_limits WHERE id = ?').bind(id).first();if(row.count>limit)authFail('Demasiados intentos. Espera unos minutos e inténtalo de nuevo.',429);
}
async function authBody(req){if(Number(req.headers.get('content-length'))>4096)authFail('Solicitud demasiado grande.',413);const reader=req.body?.getReader();if(!reader)authFail('Solicitud inválida.');let raw='',size=0;const decoder=new TextDecoder();while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>4096){await reader.cancel();authFail('Solicitud demasiado grande.',413)}raw+=decoder.decode(value,{stream:true})}try{return JSON.parse(raw+decoder.decode())}catch{authFail('Solicitud inválida.')}}
export async function authRoute(req,env){
 if(env.AUTH_MODE!=='password')return authJSON({error:'El acceso por contraseña está disponible en la instalación independiente.'},404);
 if(!env.DB)authFail('Falta conectar la base de datos del estudio.',503);
 const url=new URL(req.url),action=url.pathname.slice('/api/auth/'.length);
 if(req.method==='GET'&&action==='config')return authJSON({emails:ALLOWED_EMAILS,mailReady:!!(env.RESEND_API_KEY&&env.MAIL_FROM),initialized:!!await env.DB.prepare('SELECT id FROM auth_config WHERE id = 1').first()});
 if(req.method!=='POST')return authJSON({error:'Método no permitido.'},405);
 if(req.headers.get('origin')!==url.origin||req.headers.get('sec-fetch-site')==='cross-site')return authJSON({error:'Solicitud no autorizada.'},403);
 if(action==='logout'){const t=sessionToken(req);if(t)await env.DB.prepare('DELETE FROM auth_sessions WHERE token = ?').bind(await digest(t)).run();return authJSON({ok:true},200,{'Set-Cookie':cookie('',0)})}
 const b=await authBody(req),email=typeof b.email==='string'?b.email.trim().toLowerCase():'';
 const ip=req.headers.get('cf-connecting-ip')||'unknown';
 await rate(env,'ip:'+ip,40);
 await env.DB.prepare('DELETE FROM auth_limits WHERE expires < ?').bind(Date.now()-900000).run();
 const config=await env.DB.prepare('SELECT * FROM auth_config WHERE id = 1').first();
 if(action==='login'){
  await rate(env,'login:'+email,8);
  if(!config)authFail('El estudio aún no tiene contraseña. Solicita un enlace para crearla.',409);
  const valid=await matches(b.password,config);if(!ALLOWED_EMAILS.includes(email)||!valid)authFail('Correo o contraseña incorrectos.',401);
  const token=randomToken();await env.DB.prepare('INSERT INTO auth_sessions (token,email,version,expires) VALUES (?,?,?,?)').bind(await digest(token),email,config.version,Date.now()+43200000).run();
  return authJSON({ok:true},200,{'Set-Cookie':cookie(token)});
 }
 if(action==='recover'){
  if(!ALLOWED_EMAILS.includes(email))authFail('Selecciona uno de los tres correos autorizados.');
  if(!env.RESEND_API_KEY||!env.MAIL_FROM)authFail('La recuperación aún no está activada. Falta conectar el servicio de correo en la instalación.',503);
  await rate(env,'recover:'+email,3,3600000);await rate(env,'mail-total',9,3600000);
  const token=randomToken(),id=await digest(token),version=config?.version||0;
  await env.DB.prepare('INSERT INTO auth_resets (token,email,version,expires,used) VALUES (?,?,?,?,0)').bind(id,email,version,Date.now()+1800000).run();
  // Fragment is not sent in HTTP requests or referrers; the form posts it once.
  const link=url.origin+'/login#reset='+token;
  let response;try{response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+env.RESEND_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({from:env.MAIL_FROM,to:[email],subject:'THC · Recupera el acceso a Mi estudio',text:`Se solicitó crear o cambiar la contraseña compartida de Mi estudio. Abre este enlace, válido durante 30 minutos y para un solo uso:\n\n${link}\n\nCambiarla cerrará todas las sesiones. Si no lo pediste, ignora este correo.`}),signal:AbortSignal.timeout(15000)})}catch{response=null}
  if(!response?.ok){await env.DB.prepare('DELETE FROM auth_resets WHERE token = ?').bind(id).run();authFail('No se pudo enviar el correo. Revisa la configuración de envío e inténtalo de nuevo.',503)}
  return authJSON({ok:true,message:'Enlace enviado al correo seleccionado. Revisa también la carpeta de spam.'});
 }
 if(action==='reset'){
  if(!passwordOK(b.password))authFail('Usa una contraseña de 16 a 128 caracteres.');
  if(!/^[a-f0-9]{64}$/.test(b.token||''))authFail('El enlace no es válido o ya venció.',400);
  const id=await digest(b.token),row=await env.DB.prepare('SELECT * FROM auth_resets WHERE token = ? AND used = 0 AND expires > ?').bind(id,Date.now()).first();
  if(!row||!ALLOWED_EMAILS.includes(row.email)||row.version!==(config?.version||0))authFail('El enlace ya se usó o venció. Solicita otro.',400);
  const next=await passwordHash(b.password),version=row.version+1;
  // Conditional insert/update and token consumption execute atomically in D1.
  const results=await env.DB.batch([
   env.DB.prepare('INSERT INTO auth_config (id,salt,hash,version) SELECT 1,?,?,? WHERE EXISTS (SELECT 1 FROM auth_resets WHERE token = ? AND used = 0 AND expires > ?) ON CONFLICT(id) DO UPDATE SET salt=excluded.salt,hash=excluded.hash,version=excluded.version WHERE auth_config.version = ?').bind(next.salt,next.hash,version,id,Date.now(),row.version),
   env.DB.prepare('UPDATE auth_resets SET used = 1 WHERE token = ?').bind(id)
  ]);
  if(!results[0].meta.changes)authFail('El enlace ya se usó o la contraseña cambió. Solicita otro.',409);
  return authJSON({ok:true},200,{'Set-Cookie':cookie('',0)});
 }
 if(action==='change'){
  const user=await passwordIdentity(req,env);if(!user||!config)authFail('Inicia sesión de nuevo.',401);
  await rate(env,'change:'+user.email,8);if(!await matches(b.current,config))authFail('La contraseña actual no coincide.',401);
  if(!passwordOK(b.password))authFail('Usa una contraseña de 16 a 128 caracteres.');const next=await passwordHash(b.password);
  const result=await env.DB.prepare('UPDATE auth_config SET salt = ?, hash = ?, version = version + 1 WHERE id = 1 AND version = ?').bind(next.salt,next.hash,config.version).run();if(!result.meta.changes)authFail('La contraseña cambió en otra sesión. Inicia sesión de nuevo.',409);
  return authJSON({ok:true},200,{'Set-Cookie':cookie('',0)});
 }
 return authJSON({error:'Ruta no encontrada.'},404);
}
