# THC · Sitio completo y Mi estudio

Este paquete contiene la web pública, el panel privado, el servidor, los originales editables y una copia del perfil publicado. La web y el editor funcionarán en tu propia cuenta de Cloudflare, sin iniciar sesión con ChatGPT. No subas este paquete completo como una carpeta pública: solo sube `THC-PUBLICAR.zip` cuando completes la preparación.

## Qué incluye

- Panel de perfil, contacto (WhatsApp, Instagram y correo), fotos y encuadres.
- Tres carpetas base y hasta 27 carpetas adicionales. Puedes renombrarlas, mover archivos y eliminar carpetas adicionales vacías.
- MP3/WAV de hasta 200 MB mediante carga por partes y fotos de hasta 8 MB.
- Colores independientes para título, acentos, títulos de secciones, textos, etiquetas, enlaces y botones.
- Vista previa sin guardar y gotero que funciona tocando la foto en el iPad. El control por píxel también funciona con teclado.
- Contraseña compartida y recuperación hacia cualquiera de los tres correos permitidos.
- Borradores privados y publicación explícita. El público no puede editar.

## 1. Preparar el almacenamiento (una sola vez)

En https://dash.cloudflare.com/ crea una base D1 llamada `thc-estudio` y un bucket R2 llamado `thc-archivos`. No habilites acceso público al bucket.

En la consola SQL de D1 ejecuta `INSTALAR.sql`. Ese archivo contiene las tablas y el hash de tu contraseña inicial. Solo se usa en una base NUEVA; no lo ejecutes en la base anterior ni para actualizar el diseño. Si tu consola no permite pegar múltiples sentencias, ejecútalas una a una en el orden del archivo.

En **Workers & Pages → thcmae → Settings → Bindings**, agrega:

| Tipo | Nombre de variable | Recurso |
|---|---|---|
| D1 database | `DB` | `thc-estudio` |
| R2 bucket | `BUCKET` | `thc-archivos` |

Los nombres `DB` y `BUCKET` deben coincidir exactamente. Configura las vinculaciones para producción y vuelve a desplegar después de modificarlas. Este panel no funciona como una página HTML sin base de datos y almacenamiento.

## 2. Publicar

En el proyecto Pages `thcmae`, elige **Create deployment → Production** y carga únicamente `THC-PUBLICAR.zip`. Espera a que termine. Abre https://thcmae.pages.dev/admin.

Si vas a crear un proyecto nuevo, usa **Continue to Pages → Upload assets**, elige el nombre y configura las mismas vinculaciones. Para importar automáticamente desde el sitio anterior, usa el proyecto existente `thcmae`: es el origen autorizado por la página anterior.

El archivo `_worker.js` dentro del ZIP contiene el servidor; Cloudflare Pages admite este formato en Direct Upload. No uses un servicio que solo aloje HTML.

## 3. Entrar y entregar a THC

La contraseña inicial está en `ACCESO-PRIVADO.txt`. Puedes entrar con cualquiera de estas direcciones:

- Adaleisha.castro.20@gmail.com
- thcm4e@gmail.com
- risaiaguayo@gmail.com

Son los únicos correos permitidos. La misma contraseña sirve para los tres. En **Mi estudio → Accesos** pueden cambiarla indicando la actual. Al cambiarla se cierran todas las sesiones. Entrega a THC el enlace `/admin` y la contraseña por un canal privado; no publiques `ACCESO-PRIVADO.txt` ni `INSTALAR.sql`.

## 4. Traer las fotos y contenido actuales

El ZIP incluye la foto original entregada y una copia de los textos actuales en `respaldo/perfil-publicado.json`. Las dos fotos que se subieron después siguen en el almacenamiento del sitio anterior; no fue posible descargarlas desde este entorno.

Al entrar por primera vez al nuevo editor, pulsa **Importar página anterior**. El navegador copiará el contenido público y descargará las fotos desde el sitio anterior hacia tu almacenamiento nuevo. Revisa el borrador y pulsa **Publicar cambios**. No borres ni desactives el sitio anterior antes de finalizar la importación. Si la importación falla, puedes subir las fotos manualmente desde Perfil y portada. En la copia revisada para esta entrega no había beats publicados.

La importación solo trae la versión publicada. Los cambios posteriores del sitio anterior NO se sincronizan: después de la entrega, edita desde `/admin` en Pages. Cada nuevo archivo queda en R2 y los textos en D1; los cambios no dependen de este ZIP.

## 5. Activar recuperación por correo

El acceso con la contraseña inicial y el cambio desde el panel funcionan sin servicio de envío. Para **Olvidé mi contraseña**, configura un proveedor de correo:

1. Crea una cuenta en https://resend.com/ y verifica un dominio remitente que controles. La dirección de remitente debe estar autorizada por Resend; no pongas una dirección Gmail arbitraria.
2. Crea una clave de API para envío.
3. En **Pages → thcmae → Settings → Variables and Secrets**, agrega `RESEND_API_KEY` como **secret** y `MAIL_FROM` con el remitente verificado, por ejemplo `THC <estudio@tu-dominio-verificado.com>`.
4. Vuelve a desplegar el mismo ZIP para que se apliquen las variables.
5. En `/login`, pulsa **Olvidé la contraseña**, selecciona el correo al que tienes acceso y solicita el enlace. Pruébalo antes de dar por terminado el acceso de recuperación.

No hemos configurado una cuenta de envío ni enviado correos reales en esta entrega. Sin esos ajustes, el panel indicará que la recuperación no está activada. El enlace dura 30 minutos, se usa una vez y cambia la contraseña compartida. Nunca se envía la contraseña vieja por correo.

## Editar y conservar el código

`codigo/` contiene HTML, CSS, JavaScript, servidor, esquema y pruebas. Para generar otra versión independiente desde una computadora con Node moderno:

```sh
cd codigo
npm ci
npm test
node scripts/export-standalone.mjs ../publicar
```

Comprime el CONTENIDO de `publicar/` y súbelo como nuevo deployment; conserva las mismas vinculaciones. No vuelvas a ejecutar `INSTALAR.sql`. El archivo de recuperación solo existe en servidor; no hay claves de API dentro del código.

Para futuras migraciones, conserva también copias de D1 y R2: este ZIP es una entrega de la aplicación, no un respaldo automático de archivos que subas después.

Documentación oficial:
- https://developers.cloudflare.com/pages/get-started/direct-upload/
- https://developers.cloudflare.com/pages/functions/bindings/
- https://resend.com/docs/api-reference/emails/send-email
